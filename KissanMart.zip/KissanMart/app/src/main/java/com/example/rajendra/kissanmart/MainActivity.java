package com.example.rajendra.kissanmart;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;
    EditText et1,et2;
    TextView tv;
    String result;
    ImageButton im;
    private ProgressDialog mLoginProgress;

    private FirebaseAuth mAuth;

    private DatabaseReference mUserDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=(EditText)findViewById(R.id.LgeditText11);
        et2=(EditText)findViewById(R.id.etPassword1);
        b1=(Button)findViewById(R.id.Lgbutton);
        b2=(Button)findViewById(R.id.lgbutton21);
        mLoginProgress = new ProgressDialog(this);

        mUserDatabase = FirebaseDatabase.getInstance().getReference().child("users");
        mAuth= FirebaseAuth.getInstance();

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent(MainActivity.this,SignIn.class);
                startActivity(i1);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try
                {
                    final String email,pass;
                    email=et1.getText().toString();
                    pass=et2.getText().toString();
                    if(TextUtils.isEmpty(email))
                    {
                        Toast.makeText(MainActivity.this,"enter email",Toast.LENGTH_LONG).show();
                    }
                    else if(TextUtils.isEmpty(pass))
                    {Toast.makeText(MainActivity.this,"enter password",Toast.LENGTH_LONG).show();

                    }
                    else
                    {
                        mLoginProgress.setTitle("Logging In");
                        mLoginProgress.setMessage("Please wait while we check your credentials.");
                        mLoginProgress.setCanceledOnTouchOutside(false);
                        mLoginProgress.show();

                        loginUser(email, pass);


                    }


                }
                catch (Exception e)
                {
                    Toast.makeText(MainActivity.this,"Error:"+e,Toast.LENGTH_LONG).show();

                }






            }
        });
    }
    private void loginUser(String email, String password) {


        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){

                    mLoginProgress.dismiss();

                    final String current_user_id = mAuth.getCurrentUser().getUid();
                    String deviceToken = FirebaseInstanceId.getInstance().getToken();

                    mUserDatabase.child(current_user_id).child("device_token").setValue(deviceToken).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            FirebaseDatabase database1 = FirebaseDatabase.getInstance();
                            DatabaseReference myRef1 = database1.getReference("users").child(current_user_id);
                            myRef1.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    String name=dataSnapshot.child("name").getValue().toString();
                                    String email=dataSnapshot.child("email").getValue().toString();

                                    String city=dataSnapshot.child("city").getValue().toString();
                                    String state=dataSnapshot.child("state").getValue().toString();
                                    String image=dataSnapshot.child("user_image").getValue().toString();
                                    SessionManagement sessionManagement=new SessionManagement(getApplicationContext());
                                    sessionManagement.createLoginSession(name,email,current_user_id,state,city);


                                    Toast.makeText(MainActivity.this,"you are login Successfully",Toast.LENGTH_LONG).show();



                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {

                                }
                            });




                            Intent mainIntent = new Intent(MainActivity.this, MainPerson.class);

                            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(mainIntent);
                            finish();


                        }
                    });




                } else {

                    mLoginProgress.hide();

                    String task_result = task.getException().getMessage().toString();

                    Toast.makeText(MainActivity.this, "Error : " + task_result, Toast.LENGTH_LONG).show();

                }

            }
        });


    }

}
