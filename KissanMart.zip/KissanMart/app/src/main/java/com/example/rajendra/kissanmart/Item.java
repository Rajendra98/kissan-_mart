package com.example.rajendra.kissanmart;

/**
 * Created by Rajendra on 3/10/2018.
 */

public class Item
{
    String name,cname,category,image,actv;

    public Item(String name, String cname, String category, String image ,String actv) {
        this.name = name;
        this.cname = cname;
        this.category=category;
        this.image = image;
        this.actv=actv;
    }

    public Item() {
    }

    public String getActv() {
        return actv;
    }

    public void setActv(String actv) {
        this.actv = actv;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
