package com.example.rajendra.kissanmart;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.ArrayList;
import java.util.List;

public class SignIn extends AppCompatActivity {
    EditText et1,et2,et3,et4,et5,et6;
    Button b1;
    private FirebaseAuth mAuth;
    private ProgressDialog mRegProgress;
    String selected_item="";
    String selected_item1="";
    TextView tv;
    Spinner sp,sp1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        final String TAG = SignIn.class.getSimpleName();


        mAuth = FirebaseAuth.getInstance();
        mRegProgress = new ProgressDialog(this);
        sp=(Spinner)findViewById(R.id.spinner2);
        sp1=(Spinner)findViewById(R.id.spinner21);
        b1=(Button)findViewById(R.id.SignInbutton);
        et1=(EditText)findViewById(R.id.etFullName);
        et2=(EditText)findViewById(R.id.etEmail);
        et3=(EditText)findViewById(R.id.etMobile);
        et4=(EditText)findViewById(R.id.etAddress);
        et5=(EditText)findViewById(R.id.etDistrict);
        et6=(EditText)findViewById(R.id.etPassword);
        //spinner dropdowen element
        List<String> op1=new ArrayList<>();
        op1.add("Category");
        op1.add("Farmer");
        op1.add("Consumer");
        op1.add("Advisor");
        op1.add("businessman");
        op1.add("other");
        ArrayAdapter adapter=new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,op1);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        sp.setAdapter(adapter);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                selected_item=sp.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        //spinner dropdowen element
        List<String> op=new ArrayList<>();
        op.add("State");
        op.add("Rajasthan");
        op.add("Madhya Pradesh");
        op.add("Uttar Pradesh");
        op.add("NewDelhi");
        op.add("Hariyana");
        op.add("WestBengal");
        op.add("Andhra  Pradesh");
        op.add("Gujarat");
        op.add("Tamilnadu");
        op.add("Karnataka");
        op.add("Maharashtra");
        op.add("NorthEast");
        op.add("Kerala");
        op.add("Bihar");
        op.add("Punjab");
        op.add("Himachal Pradesh");
        op.add("Orissa");
        op.add("Chhatishgarh");
        op.add("Goa");
        op.add("Sikkim");
        op.add("Telangana");
        op.add("UttaraKhand");
        op.add("Jharkhand");


        ArrayAdapter adapter1=new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,op);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        sp1.setAdapter(adapter1);

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                selected_item1=sp.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result="";
                try
                {
                    final String name=et1.getText().toString();
                    final String email=et2.getText().toString();
                    final String mobile=et3.getText().toString();
                    final String address=et4.getText().toString();
                    final String city=et5.getText().toString();
                    final String category=selected_item;
                    final String state=selected_item1;
                    final String password=et6.getText().toString();
                    if(TextUtils.isEmpty(name)) {
                        Toast.makeText(SignIn.this, "enter Full Name", Toast.LENGTH_LONG).show();
                    }
                    else if(TextUtils.isEmpty(email)) {
                        Toast.makeText(SignIn.this, "enter Email", Toast.LENGTH_LONG).show();
                    }
                    else if(TextUtils.isEmpty(mobile)) {
                        Toast.makeText(SignIn.this, "enter Mobile", Toast.LENGTH_LONG).show();
                    }
                    else if(TextUtils.isEmpty(address)) {
                        Toast.makeText(SignIn.this, "enter Address", Toast.LENGTH_LONG).show();
                    }




                    else if(TextUtils.isEmpty(city)) {
                        Toast.makeText(SignIn.this, "enter District", Toast.LENGTH_LONG).show();
                    }
                    else if(TextUtils.isEmpty(password)) {
                        Toast.makeText(SignIn.this, "enter password", Toast.LENGTH_LONG).show();
                    }

                    else {
                        mRegProgress.setTitle("Registering User");
                        mRegProgress.setMessage("Please wait while we create your account !");
                        mRegProgress.setCanceledOnTouchOutside(false);
                        mRegProgress.show();

                        // Write a.png message to the database
                        // DatabaseReference myRef1 = database.getReference("checklogin");

                        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful())
                                {
                                    FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
                                    final String id = current_user.getUid();
                                    String device_token = FirebaseInstanceId.getInstance().getToken();



                                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                                    DatabaseReference myRef = database.getReference("users");

                                    String user_image="noimage";

                                    Person customer=new Person( id, name, mobile, email, address,  city, state,device_token,user_image,category);
                                    //CustKey key1=new CustKey(id);
                                    myRef.child(id).setValue(customer).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            mRegProgress.dismiss();
                                            if(task.isSuccessful())
                                            {
                                                Toast.makeText(SignIn.this, "your registration is complete", Toast.LENGTH_LONG).show();


                                                SessionManagement sessionManagement=new SessionManagement(getApplicationContext());
                                                sessionManagement.createLoginSession(name,email,id,"Rajashan",city);

                                                Intent i1 = new Intent(SignIn.this,MainPerson.class);

                                                i1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                startActivity(i1);
                                                finish();

                                            }
                                            else {
                                                mRegProgress.hide();

                                                String task_result = task.getException().getMessage().toString();

                                                Toast.makeText(SignIn.this, "Error : " + task_result, Toast.LENGTH_LONG).show();

                                            }

                                        }
                                    });
                                    //myRef1.setValue(id,email);



                                }
                                else {

                                    mRegProgress.hide();

                                    String task_result = task.getException().getMessage().toString();

                                    Toast.makeText(SignIn.this, "Error : " + task_result, Toast.LENGTH_LONG).show();

                                }
                            }
                        });


                    }

                }
                catch (Exception e)
                {
                    Toast.makeText(SignIn.this,"Error:"+e,Toast.LENGTH_LONG).show();

                }


            }
        });
    }
}
