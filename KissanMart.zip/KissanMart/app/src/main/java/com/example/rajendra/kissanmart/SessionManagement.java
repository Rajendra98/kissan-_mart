package com.example.rajendra.kissanmart;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/**
 * Developed  by Rajendra on 07/19/2018.

 */

public class SessionManagement {
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;
    int PRIVATE_MODE=0;
    private static final String PREF_NAME="KissanMart";
    private static final String IS_LOGIN="KissanMart";
    public static final String Key_Name="name";
    public static final String Key_email="email";
    public static final String Key_key="key";
    public static final String Key_city="city";
    public static final String Key_state="state";
    public SessionManagement(Context context)
    {
        this._context=context;
        pref=_context.getSharedPreferences(PREF_NAME,PRIVATE_MODE);
        editor=pref.edit();

    }
    public void createLoginSession(String name,String email,String key,String state,String city)
    {
        editor.putBoolean(IS_LOGIN,true);
    editor.putString(Key_email,email);
    editor.putString(Key_key,key);
    editor.putString(Key_Name,name);
    editor.putString(Key_state,state);
    editor.putString(Key_city,city);
    editor.commit();

    }
    public void checkLogin()
    {
        if (!this.isLoggedIN())
        {
            Intent i=new Intent(_context,MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            _context.startActivity(i);
        }
        else
        {

            Intent i=new Intent(_context,MainPerson.class);
            _context.startActivity(i);


        }
    }
    public void logoutUser()
    {
        editor.clear();
        editor.commit();

        Intent i=new Intent(_context,MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        _context.startActivity(i);


    }
    public boolean isLoggedIN()
    {
        return pref.getBoolean(IS_LOGIN,false);
    }
    public String currentuser()
    {
        return pref.getString(Key_key,"ke");
    }
}
