package com.example.rajendra.kissanmart;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Rajendra on 3/9/2018.
 */

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder>{
    private List<Message> mMessageList;
    private DatabaseReference mUserDatabase;
    private SharedPreferences preferences;
    public ProgressBar progressBar;
    private DialogInterface.OnClickListener onClickListener;


    public MessageAdapter(List<Message> mMessageList) {

        this.mMessageList = mMessageList;

    }

    @Override
    public MessageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.group_mess_layout ,parent, false);

        return new MessageViewHolder(v);

    }

    public class MessageViewHolder extends RecyclerView.ViewHolder {

        public TextView messageText;


        public TextView displayTime;

        public ImageView messageImage;
        public RelativeLayout relativeLayout;
        public RelativeLayout relativeLayout1;




        public MessageViewHolder(View view) {
            super(view);

            messageText = (TextView) view.findViewById(R.id.message_text_layout);
            displayTime=(TextView)view.findViewById(R.id.time_text_layout);

            messageImage = (ImageView) view.findViewById(R.id.message_image_layout);
            relativeLayout=(RelativeLayout)view.findViewById(R.id.message_single_layout);

            relativeLayout1=(RelativeLayout)view.findViewById(R.id.message_single_layout11);
            //messageImage.setOnClickListener(new A());






        }


    }

    public void onClick(View view) {
        Toast.makeText(view.getContext(), "position = " , Toast.LENGTH_SHORT).show();
    }



    @Override
    public void onBindViewHolder(final MessageViewHolder viewHolder, int i) {

        final Message c = mMessageList.get(i);

        final String from_user = c.getFrom();
       final String message_type = c.getType();
        Long time=c.getTime();
        DateFormat formatter=new SimpleDateFormat("dd/MM");
        DateFormat formatter1=new SimpleDateFormat("HH:mm");
        Calendar calendar=Calendar.getInstance();
        calendar.setTimeInMillis(time);
        final String t=formatter.format(calendar.getTime());
        final String tt=formatter1.format(calendar.getTime());
        FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
        final String idd = current_user.getUid();








                if(idd.equals(from_user))
                {
                    viewHolder.relativeLayout.setGravity(Gravity.RIGHT);
                    viewHolder.relativeLayout1.setBackgroundResource(R.drawable.mess_text_background2);
                    viewHolder.relativeLayout.setPadding(100,5,10,5);


                    viewHolder.displayTime.setText(t+" | "+tt);
                    if(message_type.equals("text")) {

                        viewHolder.messageText.setVisibility(View.VISIBLE);

                        viewHolder.messageText.setText(c.getMessage());


                        viewHolder.messageImage.setVisibility(View.GONE);


                    } else {


                        viewHolder.messageText.setVisibility(View.GONE);
                        viewHolder.messageImage.setVisibility(View.VISIBLE);



                    }



                }
                else {
                    viewHolder.relativeLayout.setGravity(Gravity.LEFT);
                    viewHolder.relativeLayout1.setBackgroundResource(R.drawable.message_text_background);

                    viewHolder.relativeLayout.setPadding(5,5,60,5);

                    viewHolder.displayTime.setText(t+" | "+tt);

                    if(message_type.equals("text")) {

                        viewHolder.messageText.setVisibility(View.VISIBLE);

                        viewHolder.messageText.setText(c.getMessage());


                        viewHolder.messageImage.setVisibility(View.GONE);


                    } else {


                        viewHolder.messageText.setVisibility(View.GONE);
                        viewHolder.messageImage.setVisibility(View.VISIBLE);



                    }



                }












    }
    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public int getItemCount() {
        return mMessageList.size();
    }

public  class ViewHolder extends RecyclerView.ViewHolder implements View.OnLongClickListener{

    public ViewHolder(View itemView) {
        super(itemView);
    }

    @Override
    public boolean onLongClick(View view) {
        return false;
    }
}



}
