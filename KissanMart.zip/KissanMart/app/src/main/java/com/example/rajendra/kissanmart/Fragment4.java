package com.example.rajendra.kissanmart;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;


public class Fragment4 extends Fragment {
    ImageView imageView;
    TextView tv;
    Button b1,b2;
    String photo,name,email;
    String result;
    Bitmap myBitmap;
    EditText t1,t2,t3,t4,t5;
    ImageButton bb1;

    Button cp1,cp2,cp3;
    private  Uri filePath;
    String ke="";

    private StorageReference mStorageRef;

    View view;
    int RESULT_OK=-1;
    public Fragment4() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view=inflater.inflate(R.layout.fragment_fragment4, container, false);
        b1=(Button)view.findViewById(R.id.Probutton1);
        //b2=(Button)findViewById(R.id.Probutton2);
        t1=(EditText)view.findViewById(R.id.ProeditText1);

        t2=(EditText)view.findViewById(R.id.ProeditText2);
        t3=(EditText)view.findViewById(R.id.ProeditText3);
        t4=(EditText)view.findViewById(R.id.ProeditText4);

        imageView=(ImageView)view.findViewById(R.id.ProimageView1);
        tv=(TextView)view.findViewById(R.id.ProtextView1);

        mStorageRef = FirebaseStorage.getInstance().getReference().child("profile_pic");
        SharedPreferences prefs = getContext().getSharedPreferences("KissanMart", 0);
        String email1 = prefs.getString("email",null);
        ke= prefs.getString("key",null);// parameter, default value
        //upLoadServerUri = "http://10.0.2.2/collage/uploadfile.php?email="+email1;


        try
        {

            FirebaseDatabase database1 = FirebaseDatabase.getInstance();
            DatabaseReference myRef1 = database1.getReference("users").child(ke);
            myRef1.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    String name=dataSnapshot.child("name").getValue().toString();
                    String cname=dataSnapshot.child("city").getValue().toString();
                    String designation=dataSnapshot.child("category").getValue().toString();
                    String state=dataSnapshot.child("state").getValue().toString();
                    String image=dataSnapshot.child("user_image").getValue().toString();
                    t1.setText(name);
                    t2.setText(cname);
                    t3.setText(designation);
                    t4.setText(state);
                    if(!image.equalsIgnoreCase("noimage"))
                    {
                        Picasso.with(getContext()).load(image).into(imageView);

                    }



                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

        }
        catch (Exception e)
        {
            Toast.makeText(getContext(),"Error:"+e,Toast.LENGTH_LONG).show();

        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                selectImage();

            }
        });


        return view;
    }
    private void selectImage()
    {
        final ItemclassforAlertDialog[] items = {
                new ItemclassforAlertDialog("Gallery", android.R.drawable.ic_menu_gallery),
                new ItemclassforAlertDialog("Camera", android.R.drawable.ic_menu_camera),
                new ItemclassforAlertDialog("Cancel",android.R.drawable.ic_menu_close_clear_cancel),//no icon for this one
        };

        ListAdapter adapter = new ArrayAdapter(
                getContext(),
                android.R.layout.select_dialog_item,
                android.R.id.text1,
                items){
            public View getView(int position, View convertView, ViewGroup parent) {
                //Use super class to create the View
                View v = super.getView(position, convertView, parent);
                TextView tv = (TextView)v.findViewById(android.R.id.text1);

                //Put the image on the TextView
                tv.setCompoundDrawablesWithIntrinsicBounds(items[position].icon, 0, 0, 0);

                //Add margin between image and text (support various screen densities)
                int dp5 = (int) (5 * getResources().getDisplayMetrics().density + 0.5f);
                tv.setCompoundDrawablePadding(dp5);

                return v;
            }
        };


        AlertDialog.Builder builder=new AlertDialog.Builder(getContext());
        builder.setTitle("Profile Photo !");


        builder.setAdapter(adapter, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int item) {
                //Toast.makeText(Profile.this,"item="+item+"no"+items[item],Toast.LENGTH_LONG).show();
                if (item==0)
                {
                    Intent intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                    startActivityForResult(intent, 2);



                }
                else if (item==1)
                {
                    Intent intent=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);

                    startActivityForResult(intent, 1);

                }
                else if (item==2)
                {

                    dialogInterface.dismiss();


                }


            }
        });
        builder.show();

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);


        if(requestCode==1 && resultCode==RESULT_OK)
        {
            filePath=data.getData();
            try {
                filePath = data.getData();
                Uri selectimage = data.getData();
                CropImage.activity(selectimage)
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setAspectRatio(1, 1)
                        .start(getContext(),Fragment4.this);
                //Toast.makeText(getContext()
                  //      , "Error:1234"+getActivity(), Toast.LENGTH_LONG).show();




            }
            catch ( Exception e)
            {

                Toast.makeText(getContext(),"Error:"+e,Toast.LENGTH_LONG).show();
            }
        }
        else if (requestCode==2 && resultCode==RESULT_OK ) {
            try {
                filePath = data.getData();
                Uri selectimage = data.getData();
                CropImage.activity(selectimage)
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setAspectRatio(1, 1)
                        .start(getContext(),Fragment4.this);
                //Toast.makeText(getContext()
                  //      , "Error:123"+getActivity(), Toast.LENGTH_LONG).show();

                    /*String[] filepath={MediaStore.Images.Media.DATA};
                    Cursor c=getContentResolver().query(selectimage,filepath,null,null,null);
                    c.moveToFirst();
                    int columnindex=c.getColumnIndex(filepath[0]);
                    String picpath=c.getString(columnindex);
                    c.close();*/
                // Bitmap thumnail=(BitmapFactory.decodeFile(picpath));
                //imageView.setImageBitmap(thumnail);

            } catch (Exception e) {
                Toast.makeText(getContext(), "Error:" + e, Toast.LENGTH_LONG).show();

            }
        }
        if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE)
        {
            //Toast.makeText(getContext()
              //      , "crop:", Toast.LENGTH_LONG).show();

            try {


                CropImage.ActivityResult activityResult = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {

                    Uri resulturi1 = activityResult.getUri();
                    StorageReference filepath = mStorageRef.child(ke + ".jpg");
                    filepath.putFile(resulturi1).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                            if (task.isSuccessful()) {


                                FirebaseDatabase database = FirebaseDatabase.getInstance();
                                DatabaseReference myRef = database.getReference("users");

                                String downloadurl = task.getResult().getDownloadUrl().toString();
                                myRef.child(ke).child("user_image").setValue(downloadurl).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        Toast.makeText(getContext(), "your profile is updated...", Toast.LENGTH_LONG).show();

                                    }
                                });

                            } else {
                                Toast.makeText(getContext()
                                        , "Error:", Toast.LENGTH_LONG).show();

                            }
                        }
                    });
                } else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    Exception error = activityResult.getError();
                    Toast.makeText(getContext()
                            , "Error:" + error, Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(getContext()
                            , "Error: pta nhi", Toast.LENGTH_LONG).show();

                }
            }
            catch (Exception e)
            {
                Toast.makeText(getContext()
                        , "Error:"+e, Toast.LENGTH_LONG).show();

            }
        }


    }



}
