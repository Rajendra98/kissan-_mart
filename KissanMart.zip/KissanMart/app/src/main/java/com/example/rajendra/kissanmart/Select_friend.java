package com.example.rajendra.kissanmart;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.*;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Select_friend extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();
    private RecyclerView recyclerView;
    private List<Item> cartList1;
    private CartListAdapter mAdapter;
    private CoordinatorLayout coordinatorLayout;
    String ke="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_friend);
        recyclerView = findViewById(R.id.recycler_viewselectfriend);
        cartList1 = new ArrayList<>();
        mAdapter = new CartListAdapter(this, cartList1);
        SharedPreferences prefs = getSharedPreferences("KissanMart", MODE_PRIVATE);

         ke = prefs.getString("key",null);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new android.support.v7.widget.DividerItemDecoration(this, android.support.v7.widget.DividerItemDecoration.VERTICAL));
        recyclerView.setAdapter(mAdapter);
        ImageButton b1=(ImageButton)findViewById(R.id.gmlbutton1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Select_friend.this,MainPerson.class);
                startActivity(intent);
            }
        });
        try {
            //ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, (RecyclerItemTouchHelper.RecyclerItemTouchHelperListener) this);
            //new ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(recyclerView);


            // making http call and fetching menu json
            prepareCart();

            /*ItemTouchHelper.SimpleCallback itemTouchHelperCallback1 = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT | ItemTouchHelper.UP) {
                @Override
                public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                    return false;
                }

                @Override
                public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                    // Row is swiped from recycler view
                    // remove it from adapter
                }

                @Override
                public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                    super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
                }
            };

            // attaching the touch helper to recycler view
            new ItemTouchHelper(itemTouchHelperCallback1).attachToRecyclerView(recyclerView);
*/

        }
        catch (Exception e)
        {
            Toast.makeText(Select_friend.this,""+e,Toast.LENGTH_LONG).show();

        }




    }
    private void prepareCart() {
        FirebaseDatabase database1 = FirebaseDatabase.getInstance();
        DatabaseReference myRef1 = database1.getReference("friends").child(ke);
        myRef1.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                String image = dataSnapshot.child("photo").getValue().toString();
                final String category = dataSnapshot.child("category").getValue().toString();
                final String name = dataSnapshot.child("name").getValue().toString();
                final String id = dataSnapshot.child("id").getValue().toString();
                Item item = new Item(name, id, category, image,"atselectfriend");
                cartList1.add(item);
                //Toast.makeText(Select_friend.this, " 1 user not found"+id+image+category+name, Toast.LENGTH_LONG).show();

                mAdapter.notifyDataSetChanged();


            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        /*myRef1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String image = dataSnapshot.child("user_image").getValue().toString();
                final String category = dataSnapshot.child("category").getValue().toString();
                final String name = dataSnapshot.child("name").getValue().toString();
                final String id = dataSnapshot.child("id").getValue().toString();
                Item item = new Item(name, id, category, image,"atselectfriend");
                cartList1.add(item);


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });*/

    }

}
