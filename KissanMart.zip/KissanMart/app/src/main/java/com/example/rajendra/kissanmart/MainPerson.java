package com.example.rajendra.kissanmart;

import android.app.ActionBar;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class MainPerson extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    Button b1,b2,b3;
    TextView tv1,tv2;
    ImageView IV;
    private int serverResponseCode = 0;
    private ProgressDialog dialog = null;
    private String upLoadServerUri = null;
    private String imagepath = null;
    String photo,name,email;
    String result;
    Bitmap myBitmap;
    ListView lst1;
    private TabLayout tabLayout11;
    private AppBarLayout appBarLayout11;
    private ViewPager viewPager11;
    ActionBar actionbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_person);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);

        View navHeaderView= navigationView.inflateHeaderView(R.layout.nav_header_main_person);

        tv1=(TextView)navHeaderView.findViewById(R.id.MCNHtextView1);
        tv2=(TextView)navHeaderView.findViewById(R.id.MCNHtextView2);
        IV=(ImageView)navHeaderView.findViewById(R.id.MCNHimageView);
        tabLayout11=(TabLayout)findViewById(R.id.tablayout1);
        viewPager11=(ViewPager)findViewById(R.id.viewpager1);
        SharedPreferences prefs = getSharedPreferences("KissanMart", MODE_PRIVATE);
        String email1 = prefs.getString("email",null);
        final String ke = prefs.getString("key",null);
        final String state = prefs.getString("state",null);
        final String name = prefs.getString("name",null);



        tv1.setText(name);
        tv2.setText(email1);
        try {

            FirebaseDatabase database1 = FirebaseDatabase.getInstance();
            DatabaseReference myRef1 = database1.getReference("users").child(ke);
            myRef1.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    String image = dataSnapshot.child("user_image").getValue().toString();
                    if (!image.equalsIgnoreCase("noimage")) {
                        Picasso.with(MainPerson.this).load(image).into(IV);

                    }


                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }
        catch (Exception e)
        {
            Toast.makeText(MainPerson.this,"Error:"+e,Toast.LENGTH_LONG).show();

        }

        navigationView.setNavigationItemSelectedListener(this);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        drawer.addDrawerListener(toggle);
        toggle.syncState();

        try{

            ViewPagerAdeptor adeptor11=new ViewPagerAdeptor(getSupportFragmentManager());

            adeptor11.addFragement(new Fragment1(),"Home");
            adeptor11.addFragement(new Fragment2(),"Network");
            adeptor11.addFragement(new Fragment3(),"chat");
            adeptor11.addFragement(new Fragment4(),"profile");
            viewPager11.setAdapter(adeptor11);
            tabLayout11.setupWithViewPager(viewPager11);


        }
        catch (Exception e)
        {
            Toast.makeText(MainPerson.this,"Error 1:"+e,Toast.LENGTH_LONG).show();


        }




    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {


        } else if (id == R.id.nav_slideshow) {


        } else if (id == R.id.nav_manage) {

            } else if (id == R.id.nav_share) {

            } else if (id == R.id.nav_logout) {

            SessionManagement obj1=new SessionManagement(getApplicationContext());
            obj1.logoutUser();
            finish();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}


