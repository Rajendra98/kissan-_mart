package com.example.rajendra.kissanmart;

import android.app.ActionBar;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class Fragment2 extends Fragment {
    private RecyclerView recyclerView;
    private List<Item> cartList;
    private CartListAdapter mAdapter;
    private CoordinatorLayout coordinatorLayout;
    private static final String URL = "https://kissan-mart.firebaseio.com/users.json";
    private String state="";

    String ke="";
    View view;

    public Fragment2() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_fragment2, container, false);
        recyclerView = view.findViewById(R.id.recycler_view);
        //coordinatorLayout = findViewById(R.id.coordinator_layout);
        cartList = new ArrayList<>();
        mAdapter = new CartListAdapter(getContext(), cartList);
        SharedPreferences prefs = getContext().getSharedPreferences("KissanMart", 0);
        ke = prefs.getString("key",null);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext().getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new android.support.v7.widget.DividerItemDecoration(getContext(), android.support.v7.widget.DividerItemDecoration.VERTICAL));
        recyclerView.setAdapter(mAdapter);


        // adding item touch helper
        // only ItemTouchHelper.LEFT added to detect Right to Left swipe
        // if you want both Right -> Left and Left -> Right
        // add pass ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT as param
        try {
            //ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, (RecyclerItemTouchHelper.RecyclerItemTouchHelperListener) this);
            //new ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(recyclerView);


            // making http call and fetching menu json
            prepareCart();

            /*ItemTouchHelper.SimpleCallback itemTouchHelperCallback1 = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT | ItemTouchHelper.UP) {
                @Override
                public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                    return false;
                }

                @Override
                public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                    // Row is swiped from recycler view
                    // remove it from adapter
                }

                @Override
                public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                    super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
                }
            };

            // attaching the touch helper to recycler view
            new ItemTouchHelper(itemTouchHelperCallback1).attachToRecyclerView(recyclerView);
*/

        }
        catch (Exception e)
        {
            Toast.makeText(getContext(),""+e,Toast.LENGTH_LONG).show();

        }

        return view;
    }
    private void prepareCart() {
        try {


            FirebaseDatabase database1 = FirebaseDatabase.getInstance();
            DatabaseReference myRef1 = database1.getReference("users");
            myRef1.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(final DataSnapshot dataSnapshot, String s) {

                    final String id=dataSnapshot.getKey();
                    //Toast.makeText(getContext(),""+id,Toast.LENGTH_LONG).show();

                    //String image = dataSnapshot.child("user_image").getValue().toString();

                    //final String id = dataSnapshot.child("id").getValue().toString();

                    final String[] fff = {"yes"};
                    //String name = dataSnapshot.child("name").getValue().toString();

                    //String category = dataSnapshot.child("category").getValue().toString();
                    String url="https://kissan-mart.firebaseio.com/friends/"+ke+".json";
                    StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {

                        public void onResponse(String response) {
                            if (response.equals("null")) {

                                //Toast.makeText(getContext(), " 1 user not found", Toast.LENGTH_LONG).show();

                                if(id.equals(ke))
                                {

                                }
                                else {

                                    String image = dataSnapshot.child("user_image").getValue().toString();
                                    final String category = dataSnapshot.child("category").getValue().toString();
                                    final String name = dataSnapshot.child("name").getValue().toString();

                                    //Toast.makeText(getContext(), " 1 user not found"+id+image+category+name, Toast.LENGTH_LONG).show();
                                    Item item = new Item(name, id, category, image,"fg2");
                                    cartList.add(item);
                                    mAdapter.notifyDataSetChanged();

                                }


                            }
                            else {
                                try {
                                    GsonBuilder gsonBuilder=new GsonBuilder();
                                    Gson gson=gsonBuilder.create();
                                    JSONObject jsonObject=new JSONObject(response);
                                    Iterator iterator=jsonObject.keys();
                                    String keyy="";
                                    Person customer=new Person();
                                    int flag =0;

                                    while (iterator.hasNext())
                                    {
                                        //Toast.makeText(getContext(),""+id,Toast.LENGTH_LONG).show();
                                        keyy=iterator.next().toString();
                                        if(keyy.equals(id))
                                        {
                                            fff[0] ="no";
                                            //Toast.makeText(getContext(),"no1",Toast.LENGTH_LONG).show();
                                            break;
                                        }
                                        //Toast.makeText(getContext(),""+keyy,Toast.LENGTH_LONG).show();



                                    }
                                    if(id.equals(ke))
                                    {

                                    }
                                    else if(fff[0].equals("no"))
                                    {
                                       // Toast.makeText(getContext(),"no",Toast.LENGTH_LONG).show();
                                    }
                                    else {
                                        String image = dataSnapshot.child("user_image").getValue().toString();
                                        final String category = dataSnapshot.child("category").getValue().toString();
                                        final String name = dataSnapshot.child("name").getValue().toString();

                                        Item item = new Item(name, id, category, image,"fg2");
                                        cartList.add(item);

                                    }


                                    mAdapter.notifyDataSetChanged();


                                }
                                catch (Exception e)
                                {
                                    Toast.makeText(getContext(), "error"+e, Toast.LENGTH_LONG).show();

                                }
                            }

                        }
                    },new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getContext(), "user not found"+error, Toast.LENGTH_LONG).show();
                            System.out.println(""+error);


                        }
                    });
                    // MyApplication.getInstance().addToRequestQueue(stringRequest);
                    RequestQueue requestQueue1= Volley.newRequestQueue(getContext());
                    requestQueue1.add(stringRequest);



                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

        }
        catch (Exception e)
        {
            Toast.makeText(getContext(),"Error:"+e,Toast.LENGTH_LONG).show();

        }


    }


}
