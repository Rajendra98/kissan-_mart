package com.example.rajendra.kissanmart;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Rajendra on 3/10/2018.
 */

public class CartListAdapter extends RecyclerView.Adapter<CartListAdapter.MyViewHolder>{
    private Context context;
    private List<Item> cartList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView name, desination;
        Button friend;
        public ImageView imageView;
        public RelativeLayout viewBackground, viewForeground;

        public MyViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.txtname);
            desination=view.findViewById(R.id.txtdesignation);
            friend=view.findViewById(R.id.btnfriend);
            imageView=view.findViewById(R.id.ImgIcon);

           }
    }


    public CartListAdapter(Context context, List<Item> cartList) {
        this.context = context;
        this.cartList = cartList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cart_list_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        final Item item = cartList.get(position);
        holder.name.setText(item.getName());

        holder.desination.setText(item.getCategory());
        if(item.actv.equals("fg2")) {
            holder.friend.setText("Follow");
        }
        else
        {
            holder.friend.setText("message");
            //holder.friend.setVisibility(View.GONE);
        }
        String image=item.getImage();
        if(!image.equals("noimage"))
        {
            Picasso.with(holder.imageView.getContext()).load(image).into(holder.imageView);

        }


        holder.friend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(item.actv.equals("fg2")) {
                    FirebaseDatabase database = FirebaseDatabase.getInstance();

                    FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
                    final String idd = current_user.getUid();
                    DatabaseReference myRef = database.getReference("friends").child(idd);
                    Friend friend = new Friend(item.cname, item.name, item.getImage(), item.category);
                    myRef.child(item.cname).setValue(friend).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            //mRegProgress.dismiss();
                            if (task.isSuccessful()) {

                                holder.friend.setText("message");
                                //holder.friend.setVisibility(View.GONE);

                                removeItem(position);

                            }
                        }
                    });
                }
                else
                {
                    Intent intent=new Intent(context,OneToOneChat.class);
                    intent.putExtra("id", ""+item.getCname());
                    Toast.makeText(context,""+item.getCname(),Toast.LENGTH_LONG).show();
                    intent.putExtra("name", ""+item.getName());
                    context.startActivity(intent);

                    //parameter, value


                }

            }
        });




        /*Glide.with(context)
                .load(item.getThumbnail())
                .into(holder.thumbnail);*/
            }

            @Override
            public int getItemCount() {
                return cartList.size();
            }

            public void removeItem(int position) {
                cartList.remove(position);
                // notify the item removed by position
                // to perform recycler view delete animations
                // NOTE: don't call notifyDataSetChanged()
                notifyItemRemoved(position);
            }

            public void restoreItem(Item item, int position) {
                cartList.add(position, item);
                // notify item added by position
                notifyItemInserted(position);
            }
        }

