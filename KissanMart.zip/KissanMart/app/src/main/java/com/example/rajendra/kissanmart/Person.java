package com.example.rajendra.kissanmart;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Rajendra on 2/19/2018.
 */

public class Person {

    @SerializedName("name")
    @Expose

    private String name;
    @SerializedName("email")
    @Expose

    private String email;
    @SerializedName("mobile")
    @Expose

    private String mobile;
    @SerializedName("state")
    @Expose


    private String state;
    @SerializedName("address")
    @Expose
    private String category;
    @SerializedName("category")
    @Expose


    private String address;
    @SerializedName("city")
    @Expose

    private String city;
    @SerializedName("id")
    @Expose

    private String id;
    @SerializedName("device_token")
    @Expose

    private String device_token;
    @SerializedName("user_image")
    @Expose

    private String user_image;



    public Person() {
    }

    public Person(String id, String name, String mobile, String email, String address, String city, String state, String device_token, String user_image,String category) {

        this.name = name;
        this.mobile = mobile;
        this.email = email;
        this.address = address;
        this.city = city;
        this.state = state;
        this.id=id;
        this.category=category;
        this.device_token=device_token;
        this.user_image=user_image;

    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDevice_token() {
        return device_token;
    }

    public void setDevice_token(String device_token) {
        this.device_token = device_token;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "Person{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +

                ", mobile='" + mobile + '\'' +
                ", email='" + email + '\'' +
                ", address='" + address + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", device_token='" + device_token + '\'' +
                '}';
    }
}
