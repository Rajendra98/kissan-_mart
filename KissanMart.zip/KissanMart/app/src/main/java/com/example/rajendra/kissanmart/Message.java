package com.example.rajendra.kissanmart;

/**
 * Created by Rajendra on 3/8/2018.
 */

public class Message
{
    private String message, type ;
    private long  time;
    private String seen;

    private String from;
    private String forr;

    public Message(String from) {
        this.from = from;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public Message(String from, String message, String seen, long time, String type, String forr) {
        this.message = message;
        this.type = type;
        this.time = time;
        this.seen = seen;
        this.forr=forr;
        this.from=from;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public String isSeen() {
        return seen;
    }

    public void setSeen(String seen) {
        this.seen = seen;
    }

    public String getForr() {
        return forr;
    }

    public void setForr(String forr) {
        this.forr = forr;
    }

    public Message(){

    }

}
