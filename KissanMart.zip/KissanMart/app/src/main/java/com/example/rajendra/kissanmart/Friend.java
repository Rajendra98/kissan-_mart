package com.example.rajendra.kissanmart; /**
 * Created by Rajendra on 7/19/2018.
 */

import java.io.Serializable;

public class Friend implements Serializable
{
    private String id;
    private String name;
    private String photo;
    private String category;

    public Friend(String id, String name, String photo, String category) {
        this.id = id;
        this.name = name;
        this.category=category;
        this.photo = photo;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhoto() {
        return photo;
    }
}
