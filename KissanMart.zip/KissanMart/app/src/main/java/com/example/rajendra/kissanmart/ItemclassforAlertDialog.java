package com.example.rajendra.kissanmart;

/**
 * Created by Rajendra on 7/23/2018.
 */

public class ItemclassforAlertDialog {
    public final String text;
    public final int icon;
    public ItemclassforAlertDialog(String text, Integer icon) {
        this.text = text;
        this.icon = icon;
    }
    @Override
    public String toString() {
        return text;
    }

}
